﻿public interface IRemoteControl
{
    void TurnOn();
    void TurnOff();
    void SetChannel(int channel);
}
