﻿public interface IValidator
{
    bool Validate();
}
